<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wound Mend - Home</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Welcome to Wound Mend</h1>
        <nav>
            <a href="assessment.html">📝 New Assessment</a>
            <a href="tracking.html">📊 Wound Tracking</a>
            <a href="healing-analysis.html">📈 Healing Analysis</a>
            <a href="wbp.html">📖 WBP Guide</a>
        </nav>
    </header>

    <main>
        <section>
            <h2>About Wound Mend</h2>
            <p>Track, assess, and manage wounds efficiently using the latest Wound Bed Preparation (WBP) 2021 Paradigm.</p>
        </section>
    </main>

    <footer>
        <p>© 2024 Wound Mend | All Rights Reserved</p>
    </footer>
</body>
</html>​// Theme Toggle Script
const themeToggle = document.getElementById("themeToggle");

if (localStorage.getItem("theme") === "dark") {
    document.documentElement.setAttribute("data-theme", "dark");
    themeToggle.textContent = "☀️ Light Mode";
} else {
    document.documentElement.setAttribute("data-theme", "light");
    themeToggle.textContent = "🌙 Dark Mode";
}

themeToggle.addEventListener("click", () => {
    const currentTheme = document.documentElement.getAttribute("data-theme");
    if (currentTheme === "dark") {
        document.documentElement.setAttribute("data-theme", "light");
        themeToggle.textContent = "🌙 Dark Mode";
        localStorage.setItem("theme", "light");
    } else {
        document.documentElement.setAttribute("data-theme", "dark");
        themeToggle.textContent = "☀️ Light Mode";
        localStorage.setItem("theme", "dark");
    }
});​// Theme Toggle Script
const themeToggle = document.getElementById("themeToggle");

// Check for saved user preference
const savedTheme = localStorage.getItem("theme");
if (savedTheme === "dark") {
  document.documentElement.setAttribute("data-theme", "dark");
  themeToggle.textContent = "☀️ Light Mode";
} else {
  document.documentElement.setAttribute("data-theme", "light");
  themeToggle.textContent = "🌙 Dark Mode";
}

// Toggle theme on button click
themeToggle.addEventListener("click", () => {
  const currentTheme = document.documentElement.getAttribute("data-theme");
  if (currentTheme === "dark") {
    document.documentElement.setAttribute("data-theme", "light");
    themeToggle.textContent = "🌙 Dark Mode";
    localStorage.setItem("theme", "light");
  } else {
    document.documentElement.setAttribute("data-theme", "dark");
    themeToggle.textContent = "☀️ Light Mode";
    localStorage.setItem("theme", "dark");
  }
});
// Theme Toggle Script
const themeToggle = document.getElementById("themeToggle");

// Check for saved user preference
const savedTheme = localStorage.getItem("theme");
if (savedTheme === "dark") {
  document.documentElement.setAttribute("data-theme", "dark");
  themeToggle.textContent = "☀️ Light Mode";
} else {
  document.documentElement.setAttribute("data-theme", "light");
  themeToggle.textContent = "🌙 Dark Mode";
}

// Toggle theme on button click
if (themeToggle) {
  themeToggle.addEventListener("click", () => {
    const currentTheme = document.documentElement.getAttribute("data-theme");
    if (currentTheme === "dark") {
      document.documentElement.setAttribute("data-theme", "light");
      themeToggle.textContent = "🌙 Dark Mode";
      localStorage.setItem("theme", "light");
    } else {
      document.documentElement.setAttribute("data-theme", "dark");
      themeToggle.textContent = "☀️ Light Mode";
      localStorage.setItem("theme", "dark");
    }
  });
}

// Dynamic Wound Staging
function updateStages() {
  const woundType = document.getElementById("woundType").value;
  const woundStage = document.getElementById("woundStage");
  woundStage.innerHTML = ""; // Clear existing options

  let stages = [];
  if (woundType === "Pressure Ulcer") {
    stages = ["Stage 1", "Stage 2", "Stage 3", "Stage 4", "Unstageable"];
  } else if (woundType === "Burn") {
    stages = ["First Degree", "Second Degree", "Third Degree"];
  } else {
    stages = ["No Stages Defined"];
  }

  stages.forEach((stage) => {
    const option = document.createElement("option");
    option.value = stage;
    option.textContent = stage;
    woundStage.appendChild(option);
  });
}

// Wound Area Calculation
function calculateArea() {
  const length = parseFloat(document.getElementById("woundLength")?.value) || 0;
  const width = parseFloat(document.getElementById("woundWidth")?.value) || 0;
  const area = length * width;
  document.getElementById("woundArea")?.textContent = area.toFixed(2);
}

// Infection Status Validation
document
  .getElementById("woundForm")
  ?.addEventListener("submit", function (event) {
    const nerdsChecked = Array.from(
      document.querySelectorAll("#nerds1, #nerds2, #nerds3, #nerds4, #nerds5")
    ).some((checkbox) => checkbox.checked);
    const stoneesChecked = Array.from(
      document.querySelectorAll(
        "#stonees1, #stonees2, #stonees3, #stonees4, #stonees5, #stonees6, #stonees7"
      )
    ).some((checkbox) => checkbox.checked);

    if (!nerdsChecked && !stoneesChecked) {
      alert("Please select at least one infection criterion.");
      event.preventDefault();
    }
  });

// Firebase Integration
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-app.js";
import {
  getFirestore,
  collection,
  addDoc
} from "https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_STORAGE_BUCKET",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

document
  .getElementById("woundForm")
  ?.addEventListener("submit", async function (event) {
    event.preventDefault();

    const assessmentData = {
      mrn: document.getElementById("mrn")?.value,
      woundType: document.getElementById("woundType")?.value,
      woundStage: document.getElementById("woundStage")?.value,
      woundLength: document.getElementById("woundLength")?.value,
      woundWidth: document.getElementById("woundWidth")?.value,
      granulation: document.getElementById("granulation")?.value,
      epithelialization: document.getElementById("epithelialization")?.value,
      slough: document.getElementById("slough")?.value,
      necrosis: document.getElementById("necrosis")?.value,
      undermining: document.getElementById("undermining")?.value,
      tunneling: document.getElementById("tunneling")?.value,
      periwound: document.getElementById("periwound")?.value,
      dressing: document.getElementById("dressing")?.value
    };

    try {
      await addDoc(collection(db, "assessments"), assessmentData);
      alert("Assessment saved successfully!");
    } catch (error) {
      console.error("Error saving assessment: ", error);
      alert("Failed to save assessment.");
    }
  });
// Auto-update wound stages based on wound type
function updateStages() {
    const woundType = document.getElementById("woundType").value;
    const woundStage = document.getElementById("woundStage");
    woundStage.innerHTML = ""; // Clear previous options

    const stageOptions = {
        "Pressure Injuries": ["Stage 1", "Stage 2", "Stage 3", "Stage 4", "Unstageable", "Deep Tissue Damage"],
        "Diabetic Foot": ["0", "1", "2", "3", "4", "5 (Wagner Scale)"],
        "Skin Tears": ["Category 1", "Category 2", "Category 3"],
        "Burn": ["First Degree", "Second Degree", "Third Degree", "Fourth Degree"],
        "Infected Surgical Wound": ["No Staging"],
        "Atypical Wound": ["No Staging"],
        "Necrotizing Fasciitis": ["No Staging"],
        "Trauma": ["No Staging"]
    };

    (stageOptions[woundType] || ["No Staging"]).forEach(stage => {
        let option = document.createElement("option");
        option.value = stage;
        option.textContent = stage;
        woundStage.appendChild(option);
    });
}

// Auto-calculate wound area (cm²)
function calculateArea() {
    const length = parseFloat(document.getElementById("woundLength").value) || 0;
    const width = parseFloat(document.getElementById("woundWidth").value) || 0;
    const area = length * width;
    document.getElementById("woundArea").textContent = area.toFixed(2);
}

// Validate form before submission
document.getElementById("woundForm").addEventListener("submit", function(event) {
    const mrn = document.getElementById("mrn").value.trim();
    const woundType = document.getElementById("woundType").value;
    const woundStage = document.getElementById("woundStage").value;
    const woundLocation = document.getElementById("woundLocation").value.trim();
    const woundLength = document.getElementById("woundLength").value;
    const woundWidth = document.getElementById("woundWidth").value;

    if (!mrn || !woundType || !woundStage || !woundLocation || !woundLength || !woundWidth) {
        alert("Please fill in all required fields.");
        event.preventDefault();
    }
});
// Simulated patient data (Replace with Firebase later)
const patients = [
    { mrn: "12345", woundType: "Pressure Injury", woundLocation: "Left Heel", lastUpdated: "2024-03-05" },
    { mrn: "67890", woundType: "Diabetic Foot", woundLocation: "Right Toe", lastUpdated: "2024-03-03" }
];

// Load patient data into the dashboard table
function loadPatients() {
    const tableBody = document.querySelector("#patientTable tbody");
    tableBody.innerHTML = ""; // Clear previous content

    patients.forEach(patient => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${patient.mrn}</td>
            <td>${patient.woundType}</td>
            <td>${patient.woundLocation}</td>
            <td>${patient.lastUpdated}</td>
            <td><a href="assessment.html?mrn=${patient.mrn}">🔍 View</a></td>
        `;
        tableBody.appendChild(row);
    });
}

// Load patients on page load
document.addEventListener("DOMContentLoaded", loadPatients);
// Simulated wound tracking data
const woundProgress = [
    { date: "2024-03-01", area: 10, granulation: 20, exudate: "Moderate", photo: "img1.jpg" },
    { date: "2024-03-07", area: 8, granulation: 40, exudate: "Low", photo: "img2.jpg" },
    { date: "2024-03-14", area: 6, granulation: 60, exudate: "None", photo: "img3.jpg" },
];

// Load wound tracking data into table
function loadTrackingData() {
    const tableBody = document.querySelector("#trackingTable tbody");
    tableBody.innerHTML = "";

    woundProgress.forEach(entry => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${entry.date}</td>
            <td>${entry.area} cm²</td>
            <td>${entry.granulation}%</td>
            <td>${entry.exudate}</td>
            <td><img src="assets/${entry.photo}" alt="Wound Image"></td>
        `;
        tableBody.appendChild(row);
    });
}

// Healing Trend Chart
function loadHealingChart() {
    const ctx = document.getElementById("healingChart").getContext("2d");
    new Chart(ctx, {
        type: "line",
        data: {
            labels: woundProgress.map(entry => entry.date),
            datasets: [
                {
                    label: "Wound Area (cm²)",
                    data: woundProgress.map(entry => entry.area),
                    borderColor: "rgba(255, 99, 132, 1)",
                    borderWidth: 2,
                    fill: false
                },
                {
                    label: "Granulation (%)",
                    data: woundProgress.map(entry => entry.granulation),
                    borderColor: "rgba(54, 162, 235, 1)",
                    borderWidth: 2,
                    fill: false
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: true }
            }
        }
    });
}

// Load data on page load
document.addEventListener("DOMContentLoaded", () => {
    if (document.getElementById("trackingTable")) {
        loadTrackingData();
    }
    if (document.getElementById("healingChart")) {
        loadHealingChart();
    }
});